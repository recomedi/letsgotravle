package com.letsgotravle.myapp.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letsgotravle.myapp.service.OpenAiService;

@Controller
@RequestMapping(value="/travel")
public class TravelController {
	
	private static final Logger logger = LoggerFactory.getLogger(TravelController.class);
	
//	@Autowired(required=false)
//	private UserIp userip;
//	
//	@Autowired
//	private MemberService memberService;
//	
//	@Autowired
//	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
    private OpenAiService openAiService;


	    // ✅ JSP 페이지 호출 (GET 요청)
	    @GetMapping("/openAiTest.do")
	    public String showOpenAiTestPage() {
	        return "WEB-INF/travel/openAiTest";  // ✅ `openAiTest.jsp`로 이동
	    }

	    // ✅ OpenAI API 호출 (POST 요청)
	    @PostMapping("/openAiTest.do")
	    @ResponseBody
	    public String getTravelRecommendation(@RequestBody Map<String, String> requestBody) {
	        String prompt = requestBody.get("prompt");
	        return openAiService.getTravelRecommendation(prompt);
	    }
	
	@RequestMapping(value = "/travelInput.do")
	public String travelInput(Model model) {
		logger.info("travelInput들어옴");				
		return "WEB-INF/travel/travelInput";
	}

	@RequestMapping(value = "/travelConditions.do")
	public String travelConditions() {
		logger.info("travelConditions들어옴");
		return "WEB-INF/travel/travelConditions";	
	}

	@RequestMapping(value = "/travelSelect.do")
	public String travelSelect() {
		logger.info("travelSelect들어옴");
		return "WEB-INF/travel/travelSelect";
	}

	@RequestMapping(value = "/travelSights.do")
	public String travelSights() {
		logger.info("travelSights들어옴");
		return "WEB-INF/travel/travelSights";
	}

	@RequestMapping(value = "/travelModify.do")
	public String travelModify() {
		logger.info("travelModify들어옴");
		return "WEB-INF/travel/travelModify";
	}

	@RequestMapping(value = "/travelDetails.do")
	public String travelDetails() {
		logger.info("travelDetails들어옴");
		return "WEB-INF/travel/travelDetails";
	}
	
}