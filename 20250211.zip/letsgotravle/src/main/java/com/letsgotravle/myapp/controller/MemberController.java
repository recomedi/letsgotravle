
package com.letsgotravle.myapp.controller;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.letsgotravle.myapp.domain.MemberVo;
import com.letsgotravle.myapp.service.MemberService;

@Controller
@RequestMapping(value="/member/")
public class MemberController {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	
	@Autowired
    private MemberService memberService;

    
    @RequestMapping(value = "memberLogin.do", method = RequestMethod.GET)
	public String memberLogin() {
		return "WEB-INF/member/memberLogin";
	}

    // 📌 로그인 처리
    @PostMapping("/loginProcess.do")
    @ResponseBody
    public HashMap<String, Object> login(@RequestParam("id") String id,
                                         @RequestParam("password") String password,
                                         HttpSession session) {
        HashMap<String, Object> response = new HashMap<>();

        MemberVo member = memberService.memberlogin(id, password); // 📌 수정 완료!
        if (member != null) {
            session.setAttribute("midx", member.getMidx());
            session.setAttribute("id", member.getId());
            session.setAttribute("nickname", member.getNickname());

            response.put("success", true);
            response.put("message", "로그인 성공");
        } else {
            response.put("success", false);
            response.put("message", "아이디 또는 비밀번호가 틀렸습니다.");
        }

        return response;
    }

    // 📌 로그아웃 처리
    @GetMapping("/logout.do")
    public String logout(HttpSession session) {
        session.invalidate(); // 세션 삭제 (로그아웃)
        return "redirect:/member/login.do"; // 로그인 페이지로 리다이렉트
    }
	
//	@Autowired(required=false)
//	private UserIp userip;
//	
//	@Autowired
//	private MemberService memberService;
//	
//	@Autowired
//	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@RequestMapping(value = "/memberFind.do")
	public String memberFind() {
		logger.info("memberFindµé¾î¿È");
		return "WEB-INF/member/memberFind";
	}
	
}
