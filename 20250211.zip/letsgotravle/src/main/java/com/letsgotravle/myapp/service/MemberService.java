package com.letsgotravle.myapp.service;

import org.apache.ibatis.annotations.Select;

import com.letsgotravle.myapp.domain.MemberVo;

public interface MemberService {

	
	 String getCurrentTime();
	 
	 
	 int saveMemberInfo(MemberVo member);


	 Integer getMemberByPhone(String phoneNumber);
		
	 MemberVo memberlogin(String id, String password);

		
}
