package com.letsgotravle.myapp.persistance;

import org.apache.ibatis.annotations.Select;

import com.letsgotravle.myapp.domain.MemberVo;

public interface MemberMapper {
	
	 @Select("SELECT NOW()")
	    String getCurrentTime();
	 int insertMember(MemberVo member);
	
}
