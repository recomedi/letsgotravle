package com.letsgotravle.myapp.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class OpenAiTest {

    private static final String API_KEY = "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"; // OpenAI API 키 입력
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";

    public static void main(String[] args) {
        try {
            String prompt = "너는 혼자 여행 여행전문가야 출발은 5월 기간은 7일 예산은 200만원 여행테마은(는) 힐링,식도락,액티비티 여행경보 2단계초과 지역은 추천하지 말아줘 여행지의 5월에 피해야하는 장소나 정확한 시기 일정별로 상세 이동경로와 식당추천 여행지의 대표관광지 대표음식 성수기여부 물가, 치안, 평균기온 위생 여행지의 교통정보,주의기간 해당날의 축제 및 행사가 있으면 알려줘 위의 내용을  추천포인트 : 대표관광지 : (3개정도) 대표음식 : (3개정도) 평균날씨 : (섭씨로 알려줘) 성수기여부 :  물가 : (한국과 비교) 치안 : 위생 : 교통 : (지하철,렌트,버스등 편리한 교통)주의해야 하는 기간 : 축제&행사 : 일정별 상세 이동경로 : (1일차: ~시부터 ~시까지 관광, ~시부터 ~시까지 식사 (정확한 식당) 이런식으로 마지막 날까지)식당의 상세정보 : 그리고 여행테마에 맞는 장소 및 행동 추천 이런식으로 6군데 알려줘 한국은 빼줘";

            // JSON 포맷 수정 (이스케이프 문제 해결)
            String payload = String.format(
                "{ \"model\": \"gpt-4o\", \"messages\": [ { \"role\": \"user\", \"content\": \"%s\" } ] }",
                prompt.replace("\"", "\\\"") // 따옴표 이스케이프 처리
            );

            // API 요청
            String response = sendPostRequest(API_URL, payload);
            System.out.println("Response: " + response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String sendPostRequest(String apiUrl, String payload) throws Exception {
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setRequestProperty("Authorization", "Bearer " + API_KEY);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Accept", "application/json"); // 추가

        // 요청 데이터 전송
        try (OutputStream os = connection.getOutputStream()) {
            os.write(payload.getBytes("UTF-8"));
            os.flush();
        }

        // 응답 읽기
        int responseCode = connection.getResponseCode();
        StringBuilder response = new StringBuilder();

        if (responseCode == 200) { // 정상 응답
            try (Scanner scanner = new Scanner(connection.getInputStream())) {
                while (scanner.hasNext()) {
                    response.append(scanner.nextLine());
                }
            }
        } else { // 오류 응답
            try (Scanner scanner = new Scanner(connection.getErrorStream())) {
                while (scanner.hasNext()) {
                    response.append(scanner.nextLine());
                }
            }
            throw new IOException("Error Response: " + response.toString()); // 오류 출력
        }

        return response.toString();
    }
}
