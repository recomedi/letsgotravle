package com.letsgotravle.myapp.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letsgotravle.myapp.persistance.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService {
	
	 @Autowired
	    private MemberMapper memberMapper;

	    @Override
	    public String getCurrentTime() {
	        return memberMapper.getCurrentTime();
	    }
	
}
