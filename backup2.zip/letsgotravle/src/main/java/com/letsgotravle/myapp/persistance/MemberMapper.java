package com.letsgotravle.myapp.persistance;

import org.apache.ibatis.annotations.Select;

public interface MemberMapper {
	
	 @Select("SELECT NOW()")
	    String getCurrentTime();
}
