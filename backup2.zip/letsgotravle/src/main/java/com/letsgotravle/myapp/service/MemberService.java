package com.letsgotravle.myapp.service;

import org.apache.ibatis.annotations.Select;

public interface MemberService {

	 @Select("SELECT NOW()")
	    String getCurrentTime();

		
}
