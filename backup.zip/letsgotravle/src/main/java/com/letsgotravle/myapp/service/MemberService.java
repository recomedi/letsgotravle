package com.letsgotravle.myapp.service;

public interface MemberService {
		
		
}
