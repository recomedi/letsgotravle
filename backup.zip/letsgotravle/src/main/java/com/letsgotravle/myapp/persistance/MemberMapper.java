package com.letsgotravle.myapp.persistance;

public interface MemberMapper {
	
	
}
