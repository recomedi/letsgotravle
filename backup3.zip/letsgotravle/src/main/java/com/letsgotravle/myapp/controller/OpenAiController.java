package com.letsgotravle.myapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.letsgotravle.myapp.service.OpenAiService;

import java.util.Map;

@RestController
@RequestMapping("/api/openai")
public class OpenAiController {

	 @Autowired
	    private OpenAiService openAiService;

	 @PostMapping("/recommend")
	 public String getTravelRecommendation(@RequestBody Map<String, String> requestBody) {
	     System.out.println("✅ OpenAI API 호출 시작");
	     String prompt = requestBody.get("prompt");
	     System.out.println("🔹 요청 프롬프트: " + prompt);
	     return openAiService.getTravelRecommendation(prompt);
	 }
}
