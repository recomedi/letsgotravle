package com.letsgotravle.myapp.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class OpenAiService {
	
	private final RestTemplate restTemplate;

    private static final String API_URL = "https://api.openai.com/v1/chat/completions";
    
    private String apiKey = "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"; // 🔹 직접 입력하여 테스트
    
    public OpenAiService() {
        this.restTemplate = new RestTemplate();
        this.restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
    }

    public String getTravelRecommendation(String prompt) {
        RestTemplate restTemplate = new RestTemplate();

        // 요청 헤더 설정
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAcceptCharset(List.of(StandardCharsets.UTF_8)); // ✅ UTF-8 설정 추가
        headers.set("Authorization", "Bearer " + apiKey);

        // 요청 바디 설정
        Map<String, Object> body = new HashMap<>();
        body.put("model", "gpt-4o");
        body.put("messages", new Object[]{
                Map.of("role", "user", "content", prompt)
        });

        // API 요청 실행
        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(body, headers);
        return restTemplate.postForObject(API_URL, requestEntity, String.class);
    }
}

